// Auto-Research Harness — one-slide animation on the Industry tokens.
const MOTION = {
  enter: Easing.easeOutCubic,
  draw: Easing.easeInOutCubic,
  pop: Easing.easeOutBack,
};

function readTokens() {
  const cs = getComputedStyle(document.documentElement);
  const g = (n, f) => (cs.getPropertyValue(n) || '').trim() || f;
  return {
    bg: g('--color-bg', '#f2f2f3'),
    text: g('--color-text', '#1d1f20'),
    accent: g('--color-accent', '#5980a6'),
    a100: g('--color-accent-100', '#eef6ff'),
    a200: g('--color-accent-200', '#d6ebff'),
    a300: g('--color-accent-300', '#b5d9fd'),
    a400: g('--color-accent-400', '#94bce3'),
    a700: g('--color-accent-700', '#416180'),
    a900: g('--color-accent-900', '#1d2d3d'),
    n300: g('--color-neutral-300', '#d4d4d7'),
    n600: g('--color-neutral-600', '#7a7a7d'),
    n700: g('--color-neutral-700', '#5d5d60'),
    n800: g('--color-neutral-800', '#424244'),
    line: g('--color-divider', 'rgba(29,31,32,0.16)'),
    mark: 'color-mix(in srgb, ' + g('--color-text', '#1d1f20') + ' 55%, transparent)',
    head: g('--font-heading', '"Barlow Condensed", sans-serif'),
    body: g('--font-body', '"Barlow", sans-serif'),
  };
}

const TokCtx = React.createContext(null);
const useTok = () => React.useContext(TokCtx);

// 0..1 progress between two authored times
function prog(T, start, end, ease) {
  return animate({ from: 0, to: 1, start, end, ease: ease || MOTION.enter })(T);
}

function Icon({ d, size = 24, color, sw = 1.5 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}
         strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round"
         style={{ display: 'block', flex: 'none' }}
         dangerouslySetInnerHTML={{ __html: d }} />
  );
}
const ICON = {
  user: '<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  unlock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
};

function Corners({ color }) {
  const arm = (pos) => (
    <i style={Object.assign({ position: 'absolute', width: 11, height: 11, color }, pos)}>
      <b style={{ position: 'absolute', left: 5, top: 0, width: 1, height: '100%', background: 'currentColor' }}></b>
      <b style={{ position: 'absolute', top: 5, left: 0, height: 1, width: '100%', background: 'currentColor' }}></b>
    </i>
  );
  return (
    <React.Fragment>
      {arm({ top: -6, left: -6 })}{arm({ top: -6, right: -6 })}
      {arm({ bottom: -6, left: -6 })}{arm({ bottom: -6, right: -6 })}
    </React.Fragment>
  );
}

// Blueprint frame: transparent, hairline, registration marks.
function Frame({ x, y, w, h, o = 1, active = 0, children, style }) {
  const k = useTok();
  const lift = (1 - o) * 14;
  return (
    <div style={Object.assign({
      position: 'absolute', left: x, top: y, width: w, height: h,
      opacity: o, transform: `translateY(${lift}px)`,
      border: `1px solid ${active > 0.5 ? k.accent : k.line}`,
      boxShadow: active > 0.5 ? `inset 0 0 0 1px ${k.accent}` : 'none',
      padding: '18px 20px', boxSizing: 'border-box',
      display: 'flex', flexDirection: 'column', gap: 6,
    }, style)}>
      <Corners color={active > 0.5 ? k.accent : k.mark} />
      {children}
    </div>
  );
}

function Kicker({ children, color, style }) {
  const k = useTok();
  return (
    <div style={Object.assign({
      fontFamily: k.head, fontWeight: 600, fontSize: 24, letterSpacing: '0.12em',
      textTransform: 'uppercase', color: color || k.n700, lineHeight: 1.1,
    }, style)}>{children}</div>
  );
}

function Body({ children, style }) {
  const k = useTok();
  return <div style={Object.assign({ fontFamily: k.body, fontSize: 25, lineHeight: 1.3, color: k.text, textWrap: 'pretty' }, style)}>{children}</div>;
}

// ---------- geometry ----------
const RING = { cx: 940, cy: 600, rx: 294, ry: 265 };
const NODE = { w: 240, h: 100 };
const STEPS = [
  ['Plan', 'new hypothesis'],
  ['Generate', 'synthetic rows'],
  ['Filter', 'leakage guard'],
  ['Train', 'fine-tune the SLM'],
  ['Evaluate', 'on LOOK rows'],
  ['Learn', 'lesson saved'],
];
const nodePos = (i) => {
  const a = (-90 + 60 * i) * Math.PI / 180;
  return { x: RING.cx + RING.rx * Math.cos(a), y: RING.cy + RING.ry * Math.sin(a) };
};
const LOOP_INTRO = 0.6, ITER = 3.6, N_ITER = 3;
const F2 = [0.48, 0.71, 0.83, 0.92];
const GOAL = 0.9;

// ---------- sections ----------
function Grid({ T, C }) {
  const k = useTok();
  const p = prog(T, 0.1, 1.6, MOTION.draw);
  const cols = [];
  for (let x = 80; x <= 1840; x += 160) cols.push(x);
  return (
    <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
      {cols.map((x, i) => (
        <line key={i} x1={x} x2={x} y1={0} y2={1080 * p} stroke={k.line} strokeWidth="1" opacity="0.45" />
      ))}
      <line x1={0} x2={1920 * p} y1={200} y2={200} stroke={k.line} strokeWidth="1" />
      <line x1={1920 - 1920 * p} x2={1920} y1={980} y2={980} stroke={k.line} strokeWidth="1" />
    </svg>
  );
}

function Header({ T, C }) {
  const k = useTok();
  const a = prog(T, 0.3, 1.1), b = prog(T, 0.6, 1.6);
  return (
    <div style={{ position: 'absolute', left: 80, top: 58, right: 80 }}>
      <Kicker color={k.a700} style={{ opacity: a, transform: `translateY(${(1 - a) * 10}px)` }}>
        VRM Compliance · Auto-Research Harness
      </Kicker>
      <div style={{
        fontFamily: k.head, fontWeight: 600, fontSize: 66, lineHeight: 1.08, letterSpacing: '-0.015em',
        color: k.text, marginTop: 10, opacity: b, transform: `translateY(${(1 - b) * 16}px)`,
      }}>Humans out of the loop where they aren’t needed. In it where they are.</div>
    </div>
  );
}

function ColumnLabels({ T, C }) {
  const k = useTok();
  const a = prog(T, C.Shift + 1.4, C.Shift + 2.0);
  const b = prog(T, C.Shift + 1.7, C.Shift + 2.3);
  const c = a;
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 80, top: 222, display: 'flex', gap: 10, alignItems: 'center', opacity: a }}>
        <Icon d={ICON.user} color={k.a700} size={24} />
        <Kicker color={k.a700}>You set the goal</Kicker>
      </div>
      <div style={{ position: 'absolute', left: RING.cx - 300, width: 600, top: 222, textAlign: 'center', opacity: b }}>
        <Kicker color={k.n700}>The research loop · no human needed</Kicker>
      </div>
      <div style={{ position: 'absolute', left: 1420, top: 222, display: 'flex', gap: 10, alignItems: 'center', opacity: c }}>
        <Icon d={ICON.user} color={k.a700} size={24} />
        <Kicker color={k.a700}>You judge and approve</Kicker>
      </div>
    </React.Fragment>
  );
}

function Inputs({ T, C, iterActive }) {
  const k = useTok();
  const g = prog(T, C.Inputs + 0.2, C.Inputs + 0.9);
  const r = prog(T, C.Inputs + 0.9, C.Inputs + 1.6);
  const bm = prog(T, C.Inputs + 1.6, C.Inputs + 2.4);
  // seal
  const split = prog(T, C.Seal + 0.3, C.Seal + 1.3, MOTION.draw);
  const lockPop = prog(T, C.Seal + 1.2, C.Seal + 1.8, MOTION.pop);
  const labels = prog(T, C.Seal + 1.5, C.Seal + 2.3);
  const opened = prog(T, C.Champion + 1.2, C.Champion + 1.6);
  const W = 350, gap = 14 * split;
  const lookW = (W - gap) * (0.695 + 0.305 * (1 - split));
  const sealW = W - gap - lookW;
  const evalOn = iterActive === 4;
  const ticks = (c) => `repeating-linear-gradient(90deg, ${c} 0 1px, transparent 1px 7px)`;
  return (
    <React.Fragment>
      <Frame x={80} y={280} w={390} h={124} o={g}>
        <Kicker>Goal, in plain English</Kicker>
        <Body>“Recall 90% and F2 90%, in 3 iterations”</Body>
      </Frame>
      <Frame x={80} y={436} w={390} h={100} o={r}>
        <Kicker>Rubric + approvals</Kicker>
        <Body>policy, data and training sign-offs</Body>
      </Frame>
      <Frame x={80} y={570} w={390} h={310} o={bm} active={evalOn ? 1 : 0}>
        <Kicker>Benchmark</Kicker>
        <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 34, lineHeight: 1.1, color: k.text }}>141 labelled real rows</div>
        <div style={{ position: 'relative', height: 58, marginTop: 14, flex: 'none' }}>
          <div style={{
            position: 'absolute', left: 0, top: 0, height: 58, width: lookW,
            background: `${ticks(k.a400)}, ${split > 0.01 ? k.a200 : k.a100}`,
            border: `1px solid ${k.a400}`, boxSizing: 'border-box',
          }}></div>
          <div style={{
            position: 'absolute', left: lookW + gap, top: 0, height: 58, width: sealW,
            background: split > 0.01 ? (opened > 0.5 ? k.a700 : k.n800) : `${ticks(k.a400)}, ${k.a100}`,
            border: `1px solid ${split > 0.01 ? k.n800 : k.a400}`, boxSizing: 'border-box',
            borderLeft: split > 0.01 ? undefined : 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div style={{ opacity: Math.min(1, lockPop * 1.2), transform: `scale(${0.4 + 0.6 * lockPop})` }}>
              <Icon d={opened > 0.5 ? ICON.unlock : ICON.lock} color={k.bg} size={30} />
            </div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '128px 1fr', rowGap: 4, alignItems: 'baseline', marginTop: 10, flex: 'none', opacity: labels, transform: `translateY(${(1 - labels) * 8}px)` }}>
          <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 27, lineHeight: 1.2, color: k.a700, letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>LOOK · 98</div>
          <Body style={{ fontSize: 24, color: k.n700, whiteSpace: 'nowrap' }}>steers the loop</Body>
          <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 27, lineHeight: 1.2, color: k.text, letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>SEALED · 43</div>
          <Body style={{ fontSize: 24, color: k.n700, whiteSpace: 'nowrap' }}>never seen</Body>
        </div>
      </Frame>
    </React.Fragment>
  );
}

function iterState(T, C) {
  const t = T - (C.Loop + LOOP_INTRO);
  if (t < 0 || t >= ITER * N_ITER) return { iter: t < 0 ? 0 : N_ITER, node: -1, f: t < 0 ? 0 : 1, done: t >= 0 };
  const iter = Math.floor(t / ITER);
  const within = (t - iter * ITER) / ITER;
  return { iter: iter + 1, node: Math.floor(within * 6), f: within, done: false };
}

function Loop({ T, C, st }) {
  const k = useTok();
  const ring = prog(T, C.Today, C.Today + 0.9, MOTION.draw);
  const nodes = STEPS.map((_, i) => prog(T, C.Today + 0.25 + i * 0.1, C.Today + 0.75 + i * 0.1, MOTION.pop));
  // today: a person hand-runs each step (slow, neutral pulse)
  let mNode = -1, mDot = null;
  const mStart = C.Today + 1.8;
  const mo = prog(T, mStart, mStart + 0.3) * (1 - prog(T, C.Shift, C.Shift + 0.4));
  if (T >= mStart && T < C.Shift + 0.4) {
    const f = Math.min(T - mStart, C.Shift - mStart) / 4.2;
    mNode = T < C.Shift ? Math.floor(f * 6) % 6 : -1;
    const a = (-90 + 360 * f) * Math.PI / 180;
    mDot = { x: RING.cx + RING.rx * Math.cos(a), y: RING.cy + RING.ry * Math.sin(a) };
  }
  // pulse travels the ellipse
  let dot = null;
  if (st.node >= 0) {
    const a = (-90 + 360 * st.f) * Math.PI / 180;
    dot = { x: RING.cx + RING.rx * Math.cos(a), y: RING.cy + RING.ry * Math.sin(a) };
  }
  const cIn = prog(T, C.Seal + 2.6, C.Seal + 3.4);
  const goalOn = st.node === 0;
  const lookOn = st.node === 4;
  return (
    <React.Fragment>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <ellipse cx={RING.cx} cy={RING.cy} rx={RING.rx} ry={RING.ry} fill="none"
                 stroke={k.a400} strokeWidth="1.5" pathLength="1"
                 strokeDasharray="1" strokeDashoffset={1 - ring}
                 transform={`rotate(-90 ${RING.cx} ${RING.cy})`} />
        {/* inputs → loop connectors */}
        <path d="M470 335 H820" fill="none" stroke={goalOn ? k.accent : k.n600} strokeWidth={goalOn ? 2.5 : 1.2}
              pathLength="1" strokeDasharray="1" strokeDashoffset={1 - cIn} />
        <path d="M470 732 H526" fill="none" stroke={lookOn ? k.accent : k.n600} strokeWidth={lookOn ? 2.5 : 1.2}
              pathLength="1" strokeDasharray="1" strokeDashoffset={1 - cIn} />
        {mDot && <circle cx={mDot.x} cy={mDot.y} r="9" fill={k.n600} opacity={mo} />}
        {dot && <circle cx={dot.x} cy={dot.y} r="9" fill={k.accent} />}
        {dot && <circle cx={dot.x} cy={dot.y} r="17" fill="none" stroke={k.accent} strokeWidth="1" opacity="0.5" />}
      </svg>
      {STEPS.map(([name, sub], i) => {
        const p = nodePos(i);
        const on = st.node === i;
        const man = mNode === i;
        const o = nodes[i];
        const edge = on ? k.accent : man ? k.n700 : k.line;
        return (
          <div key={name} style={{
            position: 'absolute', left: p.x - NODE.w / 2, top: p.y - NODE.h / 2, width: NODE.w, height: NODE.h,
            opacity: Math.min(1, o), transform: `scale(${(0.85 + 0.15 * o) * (on ? 1.05 : 1)})`,
            background: k.bg, border: `1px solid ${edge}`,
            boxShadow: on || man ? `inset 0 0 0 1px ${edge}` : 'none',
            boxSizing: 'border-box', padding: '14px 18px', display: 'flex', gap: 14, alignItems: 'flex-start',
          }}>
            <Corners color={on ? k.accent : man ? k.n700 : k.mark} />
            <div style={{
              width: 34, height: 34, flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: k.head, fontWeight: 600, fontSize: 20,
              background: on ? k.accent : 'transparent', color: on ? k.bg : k.a700,
              border: `1px solid ${on ? k.accent : k.a400}`, boxSizing: 'border-box',
            }}>{i + 1}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 34, lineHeight: 1, color: on ? k.a700 : k.text, textTransform: 'uppercase', letterSpacing: '0.02em' }}>{name}</div>
              <div style={{ fontFamily: k.body, fontSize: 24, lineHeight: 1.25, color: k.n700, whiteSpace: 'nowrap' }}>{sub}</div>
            </div>
          </div>
        );
      })}
    </React.Fragment>
  );
}

function Chart({ T, C, st }) {
  const k = useTok();
  const o = prog(T, C.Loop, C.Loop + 0.5);
  const W = 280, H = 190, X0 = 10, X1 = W - 14;
  const yv = (v) => H - 10 - ((v - 0.4) / 0.6) * (H - 26);
  const xv = (i) => X0 + (X1 - X0) * (i / 3);
  // point i appears when iteration i reaches Evaluate (node 4)
  const appear = F2.map((_, i) => {
    if (i === 0) return prog(T, C.Loop + 0.15, C.Loop + 0.55, MOTION.pop);
    const at = C.Loop + LOOP_INTRO + (i - 1) * ITER + ITER * (4 / 6);
    return prog(T, at, at + 0.45, MOTION.pop);
  });
  const segs = [];
  for (let i = 1; i < F2.length; i++) {
    const at = C.Loop + LOOP_INTRO + (i - 1) * ITER + ITER * (4 / 6);
    segs.push(prog(T, at - 0.2, at + 0.3, MOTION.draw));
  }
  const goalMet = appear[3] > 0.6;
  const champ = prog(T, C.Champion, C.Champion + 0.5, MOTION.pop);
  let label = 'Baseline';
  if (st.iter > 0 && !st.done) label = `Iteration ${st.iter} / ${N_ITER}`;
  if (st.done) label = 'Goal met';
  return (
    <div style={{ position: 'absolute', left: RING.cx - W / 2, top: 448, width: W, opacity: o }}>
      <Kicker color={goalMet ? k.accent : k.a700} style={{ textAlign: 'center', fontSize: 26, whiteSpace: 'nowrap' }}>{label}</Kicker>
      <svg width={W} height={H} style={{ display: 'block', marginTop: 14, overflow: 'visible' }}>
        <line x1={0} x2={W} y1={H - 10} y2={H - 10} stroke={k.line} />
        <line x1={0} x2={W} y1={yv(GOAL)} y2={yv(GOAL)} stroke={k.a700} strokeDasharray="6 5" strokeWidth="1.5" />
        <text x={0} y={yv(GOAL) - 10} textAnchor="start" fontFamily={k.head} fontWeight="600" fontSize="21" letterSpacing="1.5" fill={k.a700}>GOAL F2 0.90</text>
        {segs.map((p, j) => {
          const i = j + 1;
          const x1 = xv(i - 1), y1 = yv(F2[i - 1]);
          const x2 = x1 + (xv(i) - x1) * p, y2 = y1 + (yv(F2[i]) - y1) * p;
          return p > 0 ? <line key={j} x1={x1} y1={y1} x2={x2} y2={y2} stroke={k.accent} strokeWidth="2.5" /> : null;
        })}
        {F2.map((v, i) => appear[i] > 0 && (
          <rect key={i} x={xv(i) - 7} y={yv(v) - 7} width="14" height="14"
                fill={i === 3 && goalMet ? k.accent : k.bg} stroke={k.accent} strokeWidth="2"
                transform={`translate(${xv(i)} ${yv(v)}) scale(${appear[i]}) translate(${-xv(i)} ${-yv(v)})`} />
        ))}
        {champ > 0 && (
          <rect x={xv(3) - 15} y={yv(F2[3]) - 15} width="30" height="30" fill="none" stroke={k.accent} strokeWidth="1.5"
                opacity={Math.min(1, champ)}
                transform={`translate(${xv(3)} ${yv(F2[3])}) scale(${0.5 + 0.5 * champ}) translate(${-xv(3)} ${-yv(F2[3])})`} />
        )}
      </svg>
      <Body style={{ textAlign: 'center', fontSize: 24, color: k.n700, marginTop: 10 }}>F2 on LOOK rows</Body>
    </div>
  );
}

function Outputs({ T, C }) {
  const k = useTok();
  const link = prog(T, C.Champion + 0.1, C.Champion + 0.7, MOTION.draw);
  const ch = prog(T, C.Champion + 0.4, C.Champion + 1.1);
  const route = prog(T, C.Champion + 1.4, C.Champion + 2.6, MOTION.draw);
  const sc = prog(T, C.Champion + 2.3, C.Champion + 3.0);
  const barL = prog(T, C.Champion + 2.8, C.Champion + 3.6, MOTION.draw);
  const barS = prog(T, C.Champion + 3.2, C.Champion + 4.0, MOTION.draw);
  const gapNote = prog(T, C.Champion + 3.9, C.Champion + 4.4);
  const dp = prog(T, C.SignOff + 0.1, C.SignOff + 0.8);
  const tick = prog(T, C.SignOff + 1.2, C.SignOff + 1.7, MOTION.pop);
  const fill = prog(T, C.SignOff + 1.9, C.SignOff + 2.7, MOTION.draw);
  return (
    <React.Fragment>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <path d="M1354 400 H1420" fill="none" stroke={k.accent} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1 - link} />
        <path d="M410 880 V952 H1384 V616 H1420" fill="none" stroke={k.n800} strokeWidth="2"
              pathLength="1" strokeDasharray="1" strokeDashoffset={1 - route} />
      </svg>
      <div style={{ position: 'absolute', left: 560, top: 914, width: 400, opacity: route > 0.3 ? Math.min(1, (route - 0.3) * 3) : 0 }}>
        <Kicker color={k.n800} style={{ fontSize: 24 }}>Sealed rows · opened once</Kicker>
      </div>
      <Frame x={1420} y={300} w={420} h={170} o={ch} active={ch > 0.9 && T < C.Champion + 1.6 ? 1 : 0}>
        <Kicker color={k.a700}>Champion</Kicker>
        <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 36, lineHeight: 1.05 }}>Best small model</div>
        <Body style={{ color: k.n700 }}>meets the goal and the recall floor</Body>
      </Frame>
      <Frame x={1420} y={510} w={420} h={222} o={sc}>
        <Kicker color={k.a700}>Honest score</Kicker>
        <Body style={{ color: k.n700 }}>scored once, on rows it never saw</Body>
        <div style={{ display: 'grid', gridTemplateColumns: '92px 1fr', rowGap: 10, columnGap: 10, alignItems: 'center', marginTop: 8 }}>
          <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 22, letterSpacing: '0.06em', color: k.a700 }}>LOOK</div>
          <div style={{ height: 22, width: `${92 * barL}%`, background: k.a300, border: `1px solid ${k.a400}`, boxSizing: 'border-box' }}></div>
          <div style={{ fontFamily: k.head, fontWeight: 600, fontSize: 22, letterSpacing: '0.06em', color: k.text }}>SEALED</div>
          <div style={{ height: 22, width: `${88 * barS}%`, background: k.n800 }}></div>
        </div>
        <Body style={{ fontSize: 22, color: k.a700, opacity: gapNote, marginTop: 2 }}>small gap = no overfitting to LOOK</Body>
      </Frame>
      <Frame x={1420} y={772} w={420} h={150} o={dp} style={{ gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, border: `1.5px solid ${k.a700}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ opacity: Math.min(1, tick), transform: `scale(${tick})` }}><Icon d={ICON.check} color={k.a700} size={24} sw={2} /></div>
          </div>
          <Icon d={ICON.user} color={k.text} size={24} />
          <Body style={{ fontSize: 26 }}>Human sign-off</Body>
        </div>
        <div style={{ position: 'relative', height: 54, border: `1px solid ${k.accent}` }}>
          <Corners color={k.mark} />
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${100 * fill}%`, background: k.accent }}></div>
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: k.head, fontWeight: 600, fontSize: 26, letterSpacing: '0.1em', textTransform: 'uppercase',
            color: fill > 0.5 ? k.bg : k.a700,
          }}>Deploy as guardrail</div>
        </div>
      </Frame>
    </React.Fragment>
  );
}

// One person per step today; they lift out and move to the two decision points.
function Humans({ T, C }) {
  const k = useTok();
  const L = { x: 92, y: 234 }, Rt = { x: 1432, y: 234 };
  return (
    <React.Fragment>
      {STEPS.map((_, i) => {
        const p = nodePos(i);
        const sx = p.x + NODE.w / 2 - 30, sy = p.y - NODE.h / 2 - 18;
        const appear = prog(T, C.Today + 1.0 + i * 0.12, C.Today + 1.4 + i * 0.12, MOTION.pop);
        const fly = prog(T, C.Shift + 0.2 + i * 0.1, C.Shift + 1.5 + i * 0.1, MOTION.draw);
        const tgt = [0, 4, 5].indexOf(i) >= 0 ? L : Rt;
        const x = sx + (tgt.x - sx) * fly, y = sy + (tgt.y - sy) * fly - 90 * Math.sin(Math.PI * fly);
        const gone = 1 - prog(T, C.Shift + 1.45 + i * 0.1, C.Shift + 1.75 + i * 0.1);
        const o = Math.min(1, appear) * gone;
        if (o <= 0) return null;
        return (
          <div key={i} style={{
            position: 'absolute', left: x - 17, top: y - 17, width: 34, height: 34, opacity: o,
            transform: `scale(${(0.5 + 0.5 * appear) * (1 - 0.25 * fly)})`,
            background: k.bg, border: `1px solid ${fly > 0.05 ? k.a700 : k.n700}`, boxSizing: 'border-box',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Icon d={ICON.user} color={fly > 0.05 ? k.a700 : k.n800} size={22} /></div>
        );
      })}
    </React.Fragment>
  );
}

function camera(T, C, on) {
  if (!on) return { s: 1, x: 960, y: 540 };
  const end = C.Hold;
  const K = [
    [0, 1, 960, 540], [C.Today + 0.2, 1, 960, 540], [C.Today + 1.2, 1.06, 940, 560], [C.Shift + 0.1, 1.06, 940, 560],
    [C.Shift + 1.2, 1, 960, 540], [C.Inputs + 0.2, 1, 960, 540], [C.Inputs + 1.4, 1.06, 906, 560],
    [C.Seal + 3.2, 1.08, 889, 550], [C.Loop + 0.9, 1.03, 940, 555], [C.Champion - 0.2, 1.04, 960, 555],
    [C.Champion + 1.0, 1.04, 997, 560], [C.SignOff + 3.0, 1.05, 994, 560], [end + 0.9, 1, 960, 540],
  ];
  for (let i = 0; i < K.length - 1; i++) {
    const a = K[i], b = K[i + 1];
    if (T <= b[0]) {
      const p = prog(T, a[0], b[0], MOTION.draw);
      return { s: a[1] + (b[1] - a[1]) * p, x: a[2] + (b[2] - a[2]) * p, y: a[3] + (b[3] - a[3]) * p };
    }
  }
  return { s: 1, x: 960, y: 540 };
}

function Piece({ cameraOn, captionsOn, noFade }) {
  const { T, CUES, authoredTotal } = useComposition();
  const tok = React.useMemo(readTokens, []);
  const C = CUES;
  const st = iterState(T, C);
  const cam = camera(T, C, cameraOn);
  const tx = 960 - cam.x * cam.s, ty = 540 - cam.y * cam.s;
  const fadeOut = noFade ? 1 : 1 - prog(T, authoredTotal - 0.7, authoredTotal - 0.05, MOTION.draw);
  const caps = [
    { at: 0.8, until: C.Today, text: 'An automated research intern for small models.' },
    { at: C.Today + 0.3, until: C.Shift, text: 'Today, a person hand-runs every step of the research loop.' },
    { at: C.Shift + 0.2, until: C.Inputs, text: 'Move people out of the steps a machine can run, and into the decisions that need judgment.' },
    { at: C.Inputs + 0.3, until: C.Seal, text: 'You set the goal in plain English, the rubric, and what the system may use.' },
    { at: C.Seal + 0.2, until: C.Loop, text: 'The benchmark is split once. The loop can only ever look at one side.' },
    { at: C.Loop + 0.2, until: C.Loop + 6.2, text: 'The system plans, writes its own training data, trains, evaluates and learns. No human in the loop.' },
    { at: C.Loop + 6.2, until: C.Champion, text: 'It never trains on benchmark rows. It only sees aggregates of its own errors.' },
    { at: C.Champion + 0.2, until: C.SignOff, text: 'The champion is scored once on the sealed rows: the honest number.' },
    { at: C.SignOff + 0.2, until: authoredTotal - 0.7, text: 'You judge the result and approve what ships. Nothing deploys without your sign-off.' },
  ];
  return (
    <TokCtx.Provider value={tok}>
      <div data-screen-label={`t=${Math.floor(T)}s`} style={{
        position: 'absolute', inset: 0, background: tok.bg, overflow: 'hidden', color: tok.text, fontFamily: tok.body,
      }}>
        <div style={{ position: 'absolute', inset: 0, opacity: fadeOut }}>
          <div style={{ position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, transformOrigin: '0 0', transform: `translate(${tx}px, ${ty}px) scale(${cam.s})` }}>
            <Grid T={T} C={C} />
            <Header T={T} C={C} />
            <ColumnLabels T={T} C={C} />
            <Inputs T={T} C={C} iterActive={st.node} />
            <Loop T={T} C={C} st={st} />
            <Chart T={T} C={C} st={st} />
            <Outputs T={T} C={C} />
            <Humans T={T} C={C} />
          </div>
          {captionsOn && (
            <Captions items={caps} style={{
              left: 80, right: 80, bottom: 30, textAlign: 'left', padding: '18px 0 0',
              font: `500 32px ${tok.body}`, color: tok.text, textShadow: 'none',
              background: tok.bg, borderTop: `1px solid ${tok.line}`,
            }} />
          )}
        </div>
      </div>
    </TokCtx.Provider>
  );
}

function HarnessApp() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true, camera: true, captions: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#f2f2f3">
        <Piece cameraOn={t.camera} captionsOn={t.captions} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Camera push-ins" value={t.camera} onChange={(v) => setTweak('camera', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

window.HarnessApp = HarnessApp;

// Deck embed: plays once each time its slide becomes active, then holds on the full board.
const DECK_SCENES = [['Intro',3],['Today',4.5],['Shift',3],['Inputs',3.5],['Seal',4],['Loop',11.4],['Champion',5],['SignOff',4.5],['Hold',2]];
function HarnessSlide({ captions = true }) {
  const comp = React.useMemo(() => {
    const CUES = {}; let t = 0;
    let list = DECK_SCENES;
    try { if (window.OM_SCENES) list = JSON.parse(window.OM_SCENES).map((x) => [x.name, +x.dur]); } catch (e) {}
    list.forEach(([n, d]) => { CUES[n] = t; t += d; });
    return { CUES, total: t };
  }, []);
  const [T, setT] = React.useState(comp.total);
  const ref = React.useRef(null), raf = React.useRef(0);
  React.useEffect(() => {
    const stop = () => cancelAnimationFrame(raf.current);
    const start = () => {
      stop();
      const t0 = performance.now();
      const tick = (now) => {
        const t = Math.min(comp.total, (now - t0) / 1000);
        setT(t);
        if (t < comp.total) raf.current = requestAnimationFrame(tick);
      };
      setT(0); raf.current = requestAnimationFrame(tick);
    };
    const onChange = (e) => {
      const slide = e.detail && e.detail.slide;
      if (slide && ref.current && slide.contains(ref.current)) start();
      else { stop(); setT(comp.total); }
    };
    document.addEventListener('slidechange', onChange);
    if (ref.current && ref.current.closest('[data-deck-active]')) start();
    return () => { document.removeEventListener('slidechange', onChange); stop(); };
  }, []);
  const ctx = { T, CUES: comp.CUES, authoredTotal: comp.total, duration: comp.total };
  return (
    <div ref={ref} style={{ position: 'absolute', inset: 0, width: 1920, height: 1080, overflow: 'hidden' }}>
      <CompositionContext.Provider value={ctx}>
        <Piece cameraOn={true} captionsOn={captions} noFade={true} />
      </CompositionContext.Provider>
    </div>
  );
}
window.HarnessSlide = HarnessSlide;
